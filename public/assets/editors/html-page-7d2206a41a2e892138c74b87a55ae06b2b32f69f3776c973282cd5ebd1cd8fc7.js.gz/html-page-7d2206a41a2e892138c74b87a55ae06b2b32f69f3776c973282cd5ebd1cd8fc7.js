'use strict';
var htmlExample = new Editor("htmlExample", "html");
htmlExample.set_editor_text("\n<div id=\"firstDiv\">\n  Hello!\n</div>\n<div id=\"secondDiv\">\n  These are dividers =\n</div>\n<style>\n  #firstDiv {\n    height: 30px;\n    width: 200px;\n    padding: 10px;\n    background-color: #333;\n  }\n  #secondDiv {\n    \n  }\n  ");
