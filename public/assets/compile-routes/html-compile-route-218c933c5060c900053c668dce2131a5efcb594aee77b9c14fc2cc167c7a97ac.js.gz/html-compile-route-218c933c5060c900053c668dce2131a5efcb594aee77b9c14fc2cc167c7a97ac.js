'use strict';
var htmlExample = new Editor("htmlExample", "html");
htmlExample.set_editor_text("<div>test</div><div>test</div>");
var htmlExample = new Editor("htmlExample", "html");
